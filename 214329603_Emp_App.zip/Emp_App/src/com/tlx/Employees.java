package com.tlx;
import java.io.Serializable;


public class Employees implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fName;
	private String lName;
	private String email;



	public Employees() {
		this.fName = "";
		this.lName = "";
		this.email = "";

	}

	public Employees(String fName, String lName , String email) {
		this.fName = fName;
		this.lName = lName;
		this.email = email;

	}
	
	public String getfName() {
		return fName;
	}
	
	public void setFname(String fName) {
		this.fName = fName;
	}
	
	public String getlName() {
		return lName;
	}
	
	public void setlname(String lName) {
		this.lName = lName;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.fName = email;
	}
}





