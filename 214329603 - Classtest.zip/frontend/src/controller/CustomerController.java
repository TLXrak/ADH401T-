package controller;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import model.Customer;

@ManagedBean(name = "customercontroller")
@SessionScoped

public class CustomerController {

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@ManagedProperty(value="#{customer}")
	private Customer customer;
	
	public void addNewCustomer()
	{
		
		System.out.println("is in use");
	}
}
