package service;


import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import model.CustomerEntity;

 
@Stateless
@LocalBean
public class CustomerEJB {

	@PersistenceContext
	private EntityManager cust;
	
	
    public CustomerEJB() {
        // TODO Auto-generated constructor stub
    }
    
    public void addNewCustomer(CustomerEntity customerentity) {
    	System.out.println("Test database");
    	cust.persist(customerentity);
    }

}
